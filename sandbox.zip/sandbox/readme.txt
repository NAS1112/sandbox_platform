项目结构
sandbox_platform/
├── app.py
├── venv/
└──engine
    ├── rad_windows_amd64.exe
    ├── engine.exe
└── frontend/
    ├── node_modules/
    ├── public/
    ├── src/
    │   ├── assets/
    │   ├── components/
    │   │   └── ExecuteCommand.vue
    │   ├── App.vue
    │   └── main.js
    ├── .gitignore
    ├── babel.config.js
    ├── package.json
    ├── README.md
    └── vue.config.js
